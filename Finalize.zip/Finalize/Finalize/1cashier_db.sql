-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 28, 2024 at 01:08 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `1cashier_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `order_details`
--

CREATE TABLE `order_details` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `price` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int(11) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `quantity` int(11) NOT NULL,
  `category` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `product_name`, `price`, `quantity`, `category`) VALUES
(4, 'Avocado', 10.00, 999863, 'Frappe Shake'),
(5, 'Blue Berry', 24.00, 2147483642, 'Frappe Shake'),
(6, 'Cookies & Cream', 1.00, 99999975, 'Frappe Shake'),
(7, 'Dutch Choco', 0.00, 0, 'Frappe Shake'),
(8, 'Purple Yum', 200.00, 2147483646, 'Frappe Shake'),
(9, 'Strawberry', 0.00, 0, 'Frappe Shake'),
(10, 'Sweet Mango', 0.00, 0, 'Frappe Shake'),
(11, 'Lemon Iced Tea', 54.00, 3221308, 'Koolers'),
(12, 'Four Seasons', 0.00, 0, 'Koolers'),
(13, 'Red Tea', 0.00, 0, 'Koolers'),
(14, 'Blue Lemonade', 0.00, 0, 'Koolers'),
(15, 'Cucumber', 0.00, 0, 'Koolers'),
(16, 'Irene', 22.00, 22, '');

-- --------------------------------------------------------

--
-- Table structure for table `sizes`
--

CREATE TABLE `sizes` (
  `size_id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `size` varchar(20) NOT NULL,
  `price` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sizes`
--

INSERT INTO `sizes` (`size_id`, `product_id`, `size`, `price`) VALUES
(10, 4, 'Small 12oz', 60.00),
(11, 4, 'Medium 16oz', 90.00),
(12, 4, 'Large 22oz', 120.00),
(13, 5, 'Small 12oz', 60.00),
(14, 5, 'Medium 16oz', 90.00),
(15, 5, 'Large 22oz', 120.00),
(16, 6, 'Small 12oz', 60.00),
(17, 6, 'Medium 16oz', 90.00),
(18, 6, 'Large 22oz', 120.00),
(19, 7, 'Small 12oz', 60.00),
(20, 7, 'Medium 16oz', 90.00),
(21, 7, 'Large 22oz', 120.00),
(22, 8, 'Small 12oz', 60.00),
(23, 8, 'Medium 16oz', 90.00),
(24, 8, 'Large 22oz', 120.00),
(25, 9, 'Small 12oz', 60.00),
(26, 9, 'Medium 16oz', 90.00),
(27, 9, 'Large 22oz', 120.00),
(28, 10, 'Small 12oz', 60.00),
(29, 10, 'Medium 16oz', 90.00),
(30, 10, 'Large 22oz', 120.00),
(31, 11, '12oz', 35.00),
(32, 11, '16oz', 45.00),
(33, 11, '22oz', 50.00),
(34, 11, '32oz', 100.00),
(35, 12, '12oz', 35.00),
(36, 12, '16oz', 45.00),
(37, 12, '22oz', 50.00),
(38, 12, '32oz', 100.00),
(39, 13, '12oz', 35.00),
(40, 13, '16oz', 45.00),
(41, 13, '22oz', 50.00),
(42, 13, '32oz', 100.00),
(43, 14, '12oz', 35.00),
(44, 14, '16oz', 45.00),
(45, 14, '22oz', 50.00),
(46, 14, '32oz', 100.00),
(47, 15, '12oz', 35.00),
(48, 15, '16oz', 45.00),
(49, 15, '22oz', 50.00),
(50, 15, '32oz', 100.00);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('cashier','admin') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `username`, `password`, `role`) VALUES
(12, 'Admin', 'Admin', 'Admin', '$2y$10$fPK.4U15BlxgzE/d8Rv8POH2R2/7e/ILjBgH9Z0XEwe3cDWcr46LC', 'admin'),
(13, 'ee', 'ee', 'ee', '$2y$10$WRaGESVvshTaQh1d7ViHXeA.84S7NrK6ifLl3JdIHb1WYPFR7Q7JO', 'cashier'),
(14, 'ww', 'ww', 'ww', '$2y$10$22CvOXotokS/rs7UeQeveuBocCr32l83/Czz7OdJ0KoXVKJbHHOCu', 'cashier'),
(15, 'irene', 'gabakaz', 'ireney', '$2y$10$Z7i5QsQ/5bvG9OEI1o/QK.SJ6TlU56Kzp4AiyV2.Dg5cTbMHLMFRK', 'cashier'),
(16, 'qw', 'qw', 'qw', '$2y$10$OC7vuI5UzJBdUed0Fho.K.rBjzUpz6DUbsvhDIQiW7i71C3B/YnXS', 'cashier');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `order_details`
--
ALTER TABLE `order_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_id` (`order_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `sizes`
--
ALTER TABLE `sizes`
  ADD PRIMARY KEY (`size_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `order_details`
--
ALTER TABLE `order_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `sizes`
--
ALTER TABLE `sizes`
  MODIFY `size_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `order_details`
--
ALTER TABLE `order_details`
  ADD CONSTRAINT `order_details_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`);

--
-- Constraints for table `sizes`
--
ALTER TABLE `sizes`
  ADD CONSTRAINT `sizes_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
