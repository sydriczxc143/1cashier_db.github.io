<?php
session_start();
require_once "../classes/User.php";
require_once "../classes/Order.php";

if (!isset($_SESSION['user'])) {
    header("Location: ../views/index.php");
    exit;
}

$user = $_SESSION['user'];
$cart = $user->getCart();

if ($_POST['action'] === 'checkout') {
    $order = new Order();
    $order->setUserId($_SESSION['user']->getId());
    $order->setProducts($cart);
    $order->createOrder();

    $user->clearCart(); // Clear cart after successful order
    header("Location: ../views/order-receipt.php");
    exit;
}
?>