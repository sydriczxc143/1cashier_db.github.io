<?php 
session_start();

// Check if session is empty and redirect if necessary
if(empty($_SESSION)){
    header("location: ../views/");
    exit;
}

include "../classes/Product.php";

// Create an instance of the Product class
$product = new Product;

// Fetch the list of products
$product_list = $product->displayProducts();

// Process order if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['confirm_order'])) {
    $orders = $_POST['orders']; // This will contain product_id and quantity
    foreach ($orders as $product_id => $quantity) {
        if ($quantity > 0) {
            $product->adjustStock($product_id, $quantity);
        }
    }
    // Redirect to the order summary page after processing
    // Before redirecting to order-summary.php
$_SESSION['orders'] = $_POST['orders']; // Store orders in the session
header("location: order-summary.php");
exit;

}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cashier View</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" />
    <style>
        body {
            background-color: #e9f5ee; /* Light green background */
        }
        .navbar {
            background-color: #006400; /* Dark green background */
        }
        .navbar a {
            color: white;
        }
        .card {
            border: none;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .card-title {
            font-size: 1.2rem;
        }
        .quantity {
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .quantity input {
            width: 60px; /* Adjust width for input */
            text-align: center;
        }
        .btn-confirm {
            background-color: #28a745; /* Green */
            color: white;
        }
    </style>
</head>
<body>
    <!-- Navigation Bar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-white justify-content-between">
        <a href="dashboard.php" class="navbar-brand">Your Daily Cravings</a>
        <span class="navbar-text">Welcome, <?= htmlspecialchars(ucfirst($_SESSION['username'])) ?></span>
        <a href="../actions/logout.php" class="btn btn-danger">Logout</a>
    </nav>

    <div class="container mt-5">
        <h1 class="display-6 fw-bold text-center">Your Daily Cravings</h1>
        <h2 class="text-center">Select Your Products</h2>
        <form action="" method="post">
            <div class="row">
                <?php
                    // Check if product list is empty
                    if(empty($product_list)){
                ?>
                    <div class="col text-center">
                        <div class="alert alert-danger">No Products Available</div>
                    </div>
                <?php
                    } else {
                        foreach($product_list as $product_item){
                ?>
                    <div class="col-md-4 mb-4">
                        <div class="card">
                            <div class="card-body text-center">
                                <h5 class="card-title"><?= htmlspecialchars($product_item['product_name']) ?></h5>
                                <p class="card-text">Price: ₱<?= htmlspecialchars($product_item['price']) ?></p>
                                <p class="card-text">Available: <?= htmlspecialchars($product_item['quantity']) ?></p>
                                <div class="quantity">
                                    <button type="button" class="btn btn-outline-secondary" onclick="changeQuantity('<?= $product_item['product_id'] ?>', -1)">-</button>
                                    <input type="number" id="quantity-<?= $product_item['product_id'] ?>" name="orders[<?= $product_item['product_id'] ?>]" value="0" min="0" max="<?= htmlspecialchars($product_item['quantity']) ?>" class="form-control mx-2">
                                    <button type="button" class="btn btn-outline-secondary" onclick="changeQuantity('<?= $product_item['product_id'] ?>', 1)">+</button>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php
                        }
                    }
                ?>
            </div>
            <div class="text-center">
                <button type="submit" class="btn btn-confirm mt-4" name="confirm_order">Confirm Order</button>
            </div>
        </form>
    </div>

    <script>
        function changeQuantity(productId, change) {
            const quantityInput = document.getElementById(`quantity-${productId}`);
            let currentQuantity = parseInt(quantityInput.value);
            const maxQuantity = parseInt(quantityInput.max);

            currentQuantity += change;

            if (currentQuantity < 0) {
                currentQuantity = 0;
            } else if (currentQuantity > maxQuantity) {
                currentQuantity = maxQuantity;
            }

            quantityInput.value = currentQuantity;
        }
    </script>
</body>
</html>