<?php 
session_start();


// Check if session is empty and redirect if necessary
if (empty($_SESSION)) {
    header("location: ../views/");
    exit;
}

// Initialize receipt details
$transaction_number = uniqid(); // Generate a unique transaction number
$date = date("Y-m-d");
$time = date("H:i:s");
$order_details = [];
$total_price = 0;

// Retrieve the order details from the session
if (isset($_SESSION['order_details'])) {
    $order_details = $_SESSION['order_details']; // Use order details from session
    $total_price = $_SESSION['total_price']; // Get total price from session
}

// Clear the order details from session after processing
unset($_SESSION['order_details']);
unset($_SESSION['total_price']);

// Handle creating another transaction
if (isset($_POST['create_another_transaction'])) {
    header("Location: cashier.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sales Receipt</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #e6f2e6; /* Light green background */
        }
        .navbar {
            background-color: #2f8d2f; /* Darker green background */
        }
        .navbar a {
            color: white;
        }
        .receipt {
            background-color: #d4edda; /* Light green for receipt */
            padding: 20px;
            border-radius: 5px;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <!-- Navigation Bar -->
    <nav class="navbar navbar-expand-lg navbar-light">
        <a href="dashboard.php" class="navbar-brand">Your Daily Cravings</a>
        <span class="navbar-text">Welcome, <?= htmlspecialchars(ucfirst($_SESSION['username'])) ?></span>
        <form class="d-flex ms-auto" method="post">
            <button class="btn btn-danger" name="logout" type="submit">Logout</button>
        </form>
    </nav>

    <div class="container mt-5">
        <h1 class="display-6 fw-bold text-center">Sales Receipt</h1>
        <div class="receipt">
            <h2 class="text-center">Your Daily Cravings</h2>
            <p>Transaction #: <?= htmlspecialchars($transaction_number) ?></p>
            <p>Date: <?= htmlspecialchars($date) ?></p>
            <p>Time: <?= htmlspecialchars($time) ?></p>

            <table class="table table-bordered mt-4">
                <thead>
                    <tr>
                        <th>Item Description</th>
                        <th>Quantity</th>
                        <th>Price</th> <!-- Added Price column -->
                        <th>Total</th> <!-- Added Total column -->
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if (empty($order_details)) {
                        echo "<tr><td colspan='4' class='text-center'>No orders found.</td></tr>";
                    } else {
                        foreach ($order_details as $item) {
                            ?>
                                <tr>
                                    <td><?= htmlspecialchars($item['product_name']) ?></td>
                                    <td><?= htmlspecialchars($item['quantity']) ?></td>
                                    <td>₱<?= htmlspecialchars(number_format($item['price'], 2)) ?></td> <!-- Display unit price -->
                                    <td>₱<?= htmlspecialchars(number_format($item['total_price'], 2)) ?></td> <!-- Display total price -->
                                </tr>
                            <?php
                        }
                    }
                    ?>
                </tbody>
            </table>
            <h4 class="text-end">Total: ₱<?= htmlspecialchars(number_format($total_price, 2)) ?></h4>
            <p class="text-center fw-bold">Thank You For Ordering!</p>
        </div>

        <div class="text-center mt-4">
            <form method="post">
                <button class="btn btn-primary" name="create_another_transaction" type="submit">Create Another Transaction</button>
            </form>
        </div>
    </div>
</body>
</html>
