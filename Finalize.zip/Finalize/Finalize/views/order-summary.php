<?php 
session_start();

// Check if session is empty and redirect if necessary
if (empty($_SESSION)) {
    header("location: ../views/");
    exit;
}

include "../classes/Product.php";

// Create an instance of the Product class
$product = new Product;

// Initialize order details
$order_details = [];
$total_price = 0;

// Retrieve the order details from the session
if (isset($_SESSION['orders'])) {
    $orders = $_SESSION['orders']; // Assuming you store the orders in the session
    foreach ($orders as $product_id => $quantity) {
        if ($quantity > 0) {
            $product_info = $product->displaySpecificProduct($product_id); // Fetch product info
            if ($product_info) { // Ensure product exists
                $product_info['quantity'] = $quantity;
                $product_info['total_price'] = $quantity * $product_info['price']; // Calculate total price for this item
                $order_details[] = $product_info; // Add product info to order details
                $total_price += $product_info['total_price']; // Update total price
            }
        }
    }
}

// Handle payment confirmation
if (isset($_POST['confirm_payment'])) {
    // Store the order details in the session for the receipt
    $_SESSION['order_details'] = $order_details;
    $_SESSION['total_price'] = $total_price;
    
    // Redirect to sales_receipt.php
    header("Location: sales_receipt.php");
    exit;
}

// Clear the orders from session after processing
unset($_SESSION['orders']);

// Handle archiving and back to menu actions
if (isset($_POST['archive'])) {
    // Code to archive order (you can implement the logic here)
    echo "<script>alert('Order archived successfully!');</script>";
    // Redirect to manage product page or wherever you'd like
    header("Location: Archive-orders.php");
    exit;
}

if (isset($_POST['back_to_menu'])) {
    header("Location: cashier.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Summary</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #e6f2e6; /* Light green background */
        }
        .navbar {
            background-color: #2f8d2f; /* Darker green background */
        }
        .navbar a {
            color: white;
        }
        .table th, .table td {
            text-align: center;
        }
        .btn-confirm {
            background-color: #28a745; /* Green */
            color: white;
        }
        .btn-archive {
            background-color: #ffc107; /* Yellow */
            color: white;
        }
    </style>
</head>
<body>
    <!-- Navigation Bar -->
    <nav class="navbar navbar-expand-lg navbar-light">
        <a href="dashboard.php" class="navbar-brand">Your Daily Cravings</a>
        <span class="navbar-text">Welcome, <?= htmlspecialchars(ucfirst($_SESSION['username'])) ?></span>
        <form class="d-flex ms-auto" method="post">
            <button class="btn btn-danger" name="logout" type="submit">Logout</button>
        </form>
    </nav>

    <div class="container mt-5">
        <h1 class="display-6 fw-bold text-center">Order Summary</h1>
        <div class="table-responsive mt-4">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Item Description</th>
                        <th>Quantity</th>
                        <th>Price</th>
                        <th>Total Price</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // Check if order details are available
                    if (empty($order_details)) {
                        echo "<tr><td colspan='4' class='text-center'>No orders found.</td></tr>";
                    } else {
                        foreach ($order_details as $item) {
                    ?>
                        <tr>
                            <td><?= htmlspecialchars($item['product_name']) ?></td>
                            <td><?= htmlspecialchars($item['quantity']) ?></td>
                            <td>₱<?= htmlspecialchars(number_format($item['price'], 2)) ?></td>
                            <td>₱<?= htmlspecialchars(number_format($item['total_price'], 2)) ?></td>
                        </tr>
                    <?php
                        }
                    }
                    ?>
                </tbody>
            </table>
        </div>
        <h3 class="text-end">Order Total: ₱<?= htmlspecialchars(number_format($total_price, 2)) ?></h3>

        <h3 class="text-center">Select Payment</h3>
        <div class="text-center mb-4">
            <button class="btn btn-outline-secondary me-2">Cash</button>
            <span>OR</span>
            <button class="btn btn-outline-secondary ms-2">Gcash</button>
        </div>

        <form method="post" class="text-center">
            <button class="btn btn-primary" name="confirm_payment" type="submit">Confirm Payment</button>
            <button class="btn btn-archive" name="archive" type="submit">Archive</button>
            <button class="btn btn-secondary" name="back_to_menu" type="submit">Back to Menu</button>
        </form>
    </div>
</body>
</html>