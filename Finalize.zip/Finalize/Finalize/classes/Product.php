<?php

require_once "Database.php";

class Product extends Database {
    private $product_id;
    private $product_name;
    private $price;
    private $quantity;

    // Setters
    public function setProductId($product_id) {
        $this->product_id = $product_id; // Corrected variable name
    }

    public function setProductName($product_name) {
        $this->product_name = $product_name;
    }

    public function setPrice($price) {
        $this->price = $price;
    }

    public function setQuantity($quantity) {
        $this->quantity = $quantity;
    }

    // Getters
    public function getProductId() {
        return $this->product_id;
    }

    public function getProductName() {
        return $this->product_name;
    }

    public function getPrice() {
        return $this->price;
    }

    public function getQuantity() {
        return $this->quantity;
    }

    public function addProduct($product_name, $price, $quantity) {
        $this->setProductName($product_name);
        $this->setPrice($price);
        $this->setQuantity($quantity);
        
        $sql = "INSERT INTO products (product_name, price, quantity) 
                VALUES (?, ?, ?)";
        
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("sdi", $this->product_name, $this->price, $this->quantity);
        
        if ($stmt->execute()) {
            header("location: ../views/manage-product.php");
            exit;
        } else {
            die("Error in Adding: " . $stmt->error);
        }
    }

    public function displaySpecificProduct($product_id) {
        $sql = "SELECT * FROM products WHERE product_id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $product_id);
        $stmt->execute();
        
        $result = $stmt->get_result();
        if ($result->num_rows > 0) {
            $product = $result->fetch_assoc();
            $this->setProductId($product['product_id']);
            $this->setProductName($product['product_name']);
            $this->setPrice($product['price']);
            $this->setQuantity($product['quantity']);
            return $product;
        } else {
            die("Error in retrieving product: " . $this->conn->error);
        }
    }

    public function editProduct($product_id, $product_name, $price, $quantity) {
        $this->setProductId($product_id);
        $this->setProductName($product_name);
        $this->setPrice($price);
        $this->setQuantity($quantity);

        $sql = "UPDATE products
                SET product_name = ?,
                    price = ?,
                    quantity = ?
                WHERE product_id = ?";

        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("sdii", $this->product_name, $this->price, $this->quantity, $this->product_id);

        if ($stmt->execute()) {
            header("location: ../views/manage-product.php");
            exit;
        } else {
            die("Error in editing product: " . $stmt->error);
        }
    }

    public function displayProducts() {
        $sql = "SELECT * FROM products";
        
        $items = []; // Initialize the array before the loop
    
        if ($result = $this->conn->query($sql)) {
            while ($item = $result->fetch_assoc()) {
                $items[] = $item; // No need to set properties here
            }
            return $items;
        } else {
            die("Error in retrieving: " . $this->conn->error);
        }
    }    

    public function deleteProduct($product_id) {
        $sql = "DELETE FROM products WHERE product_id = ?";
        
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $product_id);

        if ($stmt->execute()) {
            header("location: ../views/manage-product.php");
            exit;
        } else {
            die("Error in deleting product: " . $stmt->error);
        }
    }

    public function adjustStock($product_id, $buy_quantity) {
        // Fetch current stock
        $sql = "SELECT quantity FROM products WHERE product_id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $product_id);
        $stmt->execute();
        
        $result = $stmt->get_result();
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $current_quantity = $row['quantity'];

            if ($current_quantity >= $buy_quantity) {
                // Update the quantity in the database
                $new_quantity = $current_quantity - $buy_quantity;
                $update_sql = "UPDATE products SET quantity = ? WHERE product_id = ?";
                $update_stmt = $this->conn->prepare($update_sql);
                $update_stmt->bind_param("ii", $new_quantity, $product_id);

                if ($update_stmt->execute()) {
                    return true; // Stock adjusted successfully
                } else {
                    die("Error in adjusting stock: " . $update_stmt->error);
                }
            } else {
                // Not enough stock
                return false;
            }
        }
        return false; // Product not found
    }
}