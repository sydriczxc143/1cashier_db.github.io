<?php
require_once "Database.php";

class Order extends Database {
    private $userId;
    private $products = [];

    // Setters
    public function setUserId($userId) {
        $this->userId = $userId;
    }

    public function setProducts($products) {
        $this->products = $products;
    }

    // Function to create order
    public function createOrder() {
        $sql = "INSERT INTO orders (user_id) VALUES ('$this->userId')";
        
        if ($this->conn->query($sql)) {
            $orderId = $this->conn->insert_id; // Get last inserted order id
            foreach ($this->products as $product) {
                $productName = $product->getName();
                $productPrice = $product->getPrice();
                $sql = "INSERT INTO order_details (order_id, product_name, price) 
                        VALUES ('$orderId', '$productName', '$productPrice')";
                if (!$this->conn->query($sql)) {
                    die("Error in creating order: " . $this->conn->error);
                }
            }
        } else {
            die("Error in creating order: " . $this->conn->error);
        }
    }
}
?>