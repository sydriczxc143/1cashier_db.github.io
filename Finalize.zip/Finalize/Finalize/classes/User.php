<?php
require_once "Database.php";

class User extends Database {

    // Registration method
    public function register($first_name, $last_name, $username, $password) {
        // Automatically assign the role of 'cashier'
        $role = 'cashier';

        $sql = "INSERT INTO users (first_name, last_name, username, password, role)
                VALUES ('$first_name', '$last_name', '$username', '$password', '$role')";

        if ($this->conn->query($sql)) {
            header("Location: ../views/Index.php");
            exit;
        } else {
            die("Error in Registering: " . $this->conn->error);
        }
    }

    // Login method
    public function login($username, $password) {
        // Static check for Admin account
        if ($username == 'Admin' && $password == 'Admin') {
            session_start();
            $_SESSION['id'] = 1; // You can use a static admin id (or fetch one if needed)
            $_SESSION['username'] = 'Admin';
            $_SESSION['role'] = 'admin';

            header("Location: ../views/manage-product.php");
            exit;
        }

        // Check database for other users
        $sql = "SELECT * FROM users WHERE username = '$username'";
        $result = $this->conn->query($sql);

        if ($result->num_rows == 1) {
            $user = $result->fetch_assoc();
            if (password_verify($password, $user['password'])) {
                session_start();
                $_SESSION['id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['role'] = $user['role'];  // Store the user role in session

                // Redirect based on user role
                if ($user['role'] == 'admin') {
                    header("Location: ../views/manage-product.php");
                } elseif ($user['role'] == 'cashier') {
                    header("Location: ../views/cashier.php");
                }
                exit;
            } else {
                die("Password is incorrect");
            }
        } else {
            die("Username not found");
        }
    }
}
?>